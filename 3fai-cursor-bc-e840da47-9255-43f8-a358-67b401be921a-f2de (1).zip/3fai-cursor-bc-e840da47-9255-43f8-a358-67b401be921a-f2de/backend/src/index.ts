import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import dayjs from 'dayjs';
import cron from 'node-cron';
import { randomUUID } from 'crypto';
import { verifyTelegramInitData } from './telegram.js';

dotenv.config();

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGIN?.split(',') ?? true }));
app.use(express.json());

const limiter = rateLimit({ windowMs: 60 * 1000, max: 60 });
app.use(limiter);

// In-memory demo store (replace with DB)
interface User {
	id: string; // telegram id
	username?: string;
	eton: number; // eTON integer balance
	tonDeposited: number; // total TON deposited (for stats)
	tonAvailableForWithdraw: number; // derived via vesting accrual
	activeDays: number; // consecutive days
	lastActiveAt?: number; // ms
	lastWithdrawAt?: number; // ms
	achievements: string[];
	inventory: {
		water: number;
		energy: number;
		buildings: Record<string, number>;
	};
	vesting: Array<{ id: string; totalEton: number; dailyEton: number; startAt: number; daysClaimed: number }>;
	marketDailyCount: number;
}

const users = new Map<string, User>();

const INTERNAL_RATE_ETON_PER_TON = 1000; // 1 TON == 1000 eTON
const MIN_WITHDRAW_TON = 0.9;
const WITHDRAW_COOLDOWN_DAYS = 7;

function getOrCreateUser(id: string, username?: string): User {
	let u = users.get(id);
	if (!u) {
		u = {
			id,
			eton: 10,
			tonDeposited: 0,
			tonAvailableForWithdraw: 0,
			activeDays: 0,
			lastActiveAt: Date.now(),
			achievements: [],
			inventory: { water: 10, energy: 10, buildings: { house: 1, well: 1, panel: 1 } },
			vesting: [],
			marketDailyCount: 0,
		};
		if (username !== undefined) {
			u.username = username;
		}
		users.set(id, u);
	}
	return u;
}

function accrueVesting(user: User) {
	const now = dayjs();
	let newlyAccruedEton = 0;
	for (const v of user.vesting) {
		const daysSinceStart = Math.floor(now.diff(dayjs(v.startAt), 'day'));
		const claimableDays = Math.max(0, Math.min(30, daysSinceStart) - v.daysClaimed);
		if (claimableDays > 0) {
			v.daysClaimed += claimableDays;
			newlyAccruedEton += claimableDays * v.dailyEton;
		}
	}
	if (newlyAccruedEton > 0) {
		user.eton += newlyAccruedEton;
	}
}

// Daily reset: events, market counters, active streaks
cron.schedule('0 12 * * *', () => {
	for (const u of users.values()) {
		// simulate event scheduling here (stub)
		u.marketDailyCount = 0;
		// increment active day if user was active in last 24h
		if (u.lastActiveAt && dayjs().diff(dayjs(u.lastActiveAt), 'day') === 0) {
			u.activeDays += 1;
		}
	}
});

app.post('/api/auth/telegram', (req, res) => {
	const schema = z.object({
		initData: z.string().optional(),
		dev: z.object({ id: z.string(), username: z.string().optional() }).optional(),
	});
	const parsed = schema.safeParse(req.body);
	if (!parsed.success) return res.status(400).json({ error: 'invalid_payload' });

	const botToken = process.env.TELEGRAM_BOT_TOKEN;
	const initData = parsed.data.initData;
	if (initData && botToken) {
		const v = verifyTelegramInitData(initData, botToken);
		if (!v.valid || !v.user) return res.status(401).json({ error: v.error || 'unauthorized' });
		const user = getOrCreateUser(v.user.id, v.user.username);
		accrueVesting(user);
		return res.json({ user });
	}

	// Fallback for local development only
	if (process.env.NODE_ENV !== 'production' && parsed.data.dev) {
		const user = getOrCreateUser(parsed.data.dev.id, parsed.data.dev.username);
		accrueVesting(user);
		return res.json({ user, dev: true });
	}

	return res.status(401).json({ error: 'missing_initData' });
});

app.post('/api/deposit', (req, res) => {
	// After TON Connect payment is confirmed client-side, server records deposit
	const schema = z.object({ id: z.string(), ton: z.number().positive() });
	const parse = schema.safeParse(req.body);
	if (!parse.success) return res.status(400).json({ error: 'Invalid deposit' });
	const user = getOrCreateUser(parse.data.id);
	const etonTotal = Math.round(parse.data.ton * INTERNAL_RATE_ETON_PER_TON);
	const tenPercent = Math.floor(etonTotal * 0.1);
	const ninetyPercent = etonTotal - tenPercent;
	user.eton += tenPercent; // immediate
	user.tonDeposited += parse.data.ton;
	user.vesting.push({ id: randomUUID(), totalEton: ninetyPercent, dailyEton: Math.floor(ninetyPercent / 30), startAt: Date.now(), daysClaimed: 0 });
	user.lastActiveAt = Date.now();
	return res.json({ ok: true });
});

app.get('/api/user/:id', (req, res) => {
	const user = getOrCreateUser(req.params.id);
	accrueVesting(user);
	return res.json({ user });
});

app.post('/api/withdraw', (req, res) => {
	const schema = z.object({ id: z.string(), amountTon: z.number().positive() });
	const parse = schema.safeParse(req.body);
	if (!parse.success) return res.status(400).json({ error: 'Invalid withdraw' });
	const user = getOrCreateUser(parse.data.id);
	accrueVesting(user);
	const now = dayjs();
	if (user.activeDays < 5) return res.status(400).json({ error: 'need_active_5_days' });
	if (user.lastWithdrawAt && now.diff(dayjs(user.lastWithdrawAt), 'day') < WITHDRAW_COOLDOWN_DAYS) {
		return res.status(400).json({ error: 'cooldown_7_days' });
	}
	const etonEquivalent = Math.floor(parse.data.amountTon * INTERNAL_RATE_ETON_PER_TON);
	if (parse.data.amountTon < MIN_WITHDRAW_TON) {
		return res.status(400).json({ error: 'min_0_9_ton' });
	}
	if (user.eton < etonEquivalent) {
		return res.status(400).json({ error: 'insufficient_eton' });
	}
	user.eton -= etonEquivalent;
	user.lastWithdrawAt = Date.now();
	user.lastActiveAt = Date.now();
	// TODO: initiate TON transfer via server-side wallet or custodial process
	return res.json({ ok: true });
});

app.post('/api/market/list', (req, res) => {
	const schema = z.object({ id: z.string(), type: z.enum(['water', 'energy']), amount: z.number().int().positive(), pricePerUnit: z.number().int().positive() });
	const parse = schema.safeParse(req.body);
	if (!parse.success) return res.status(400).json({ error: 'Invalid listing' });
	const user = getOrCreateUser(parse.data.id);
	if (user.marketDailyCount >= 100) return res.status(400).json({ error: 'limit_100_day' });
	user.marketDailyCount += 1;
	user.lastActiveAt = Date.now();
	return res.json({ ok: true, fee: 5 });
});

app.get('/health', (_req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend running on :${PORT}`));

