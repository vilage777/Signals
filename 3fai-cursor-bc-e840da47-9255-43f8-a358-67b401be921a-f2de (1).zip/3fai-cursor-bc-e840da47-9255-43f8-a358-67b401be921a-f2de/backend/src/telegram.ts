import { createHmac } from 'crypto';

export type TelegramInitDataVerification = {
	valid: boolean;
	error?: string;
	user?: { id: string; username?: string };
};

function buildDataCheckString(initData: string): { dataCheckString: string; hash: string | undefined } {
	const params = new URLSearchParams(initData);
	const hash = params.get('hash') ?? undefined;
	if (hash) params.delete('hash');
	const pairs: string[] = [];
	const entries = Array.from(params.entries()).sort((a, b) => a[0].localeCompare(b[0]));
	for (const [key, value] of entries) {
		pairs.push(`${key}=${value}`);
	}
	return { dataCheckString: pairs.join('\n'), hash };
}

export function verifyTelegramInitData(initData: string, botToken: string): TelegramInitDataVerification {
	try {
		const { dataCheckString, hash } = buildDataCheckString(initData);
		if (!hash) return { valid: false, error: 'missing_hash' };
		const secretKey = createHmac('sha256', 'WebAppData').update(botToken).digest();
		const computedHash = createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
		if (computedHash !== hash) {
			return { valid: false, error: 'invalid_hash' };
		}
		const params = new URLSearchParams(initData);
		const userRaw = params.get('user');
		let userId = params.get('id') ?? undefined;
		let username: string | undefined = undefined;
		if (userRaw) {
			try {
				const userObj = JSON.parse(userRaw);
				userId = userObj?.id?.toString?.() ?? userId;
				username = userObj?.username ?? undefined;
			} catch {
				// ignore
			}
		}
		if (!userId) return { valid: false, error: 'missing_user' };
		const resultUser: { id: string; username?: string } = { id: userId };
		if (username !== undefined) {
			resultUser.username = username;
		}
		return { valid: true, user: resultUser };
	} catch (e) {
		return { valid: false, error: 'exception' };
	}
}

