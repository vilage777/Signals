import { useEffect, useMemo, useState } from 'react'
import './App.css'
import WebApp from '@twa-dev/sdk'
import { TonConnectUIProvider, TonConnectButton, useTonConnectUI } from '@tonconnect/ui-react'
import axios from 'axios'
import { Withdraw } from './components/Withdraw'

type User = {
  id: string
  username?: string
  eton: number
  activeDays: number
}

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000'

function WalletSection({ userId }: { userId: string }) {
  const [tonConnectUI] = useTonConnectUI()
  const [loading, setLoading] = useState(false)
  const depositOptions = [1, 5, 10, 50, 500]

  const handleDeposit = async (amountTon: number) => {
    setLoading(true)
    try {
      // Here you would create and send a TON transfer request via tonConnectUI
      // For MVP we assume success and notify backend to record vesting schedule
      await axios.post(`${API_BASE}/api/deposit`, { id: userId, ton: amountTon })
      alert(`Пополнение ${amountTon} TON успешно! 10% eTON начислены сразу, 90% — на 30 дней.`)
    } catch (e) {
      alert('Ошибка пополнения')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <TonConnectButton />
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {depositOptions.map((v) => (
          <button key={v} disabled={loading} onClick={() => handleDeposit(v)}>
            Пополнить {v} TON
          </button>
        ))}
      </div>
    </div>
  )
}

function AppInner() {
  const [user, setUser] = useState<User | null>(null)

  const initDataUnsafe = WebApp?.initDataUnsafe as any
  const initDataRaw = (WebApp as any)?.initData as string | undefined
  const userId = useMemo(() => {
    // For local dev fallback
    return initDataUnsafe?.user?.id?.toString?.() || 'dev-user-1'
  }, [initDataUnsafe])
  const username = initDataUnsafe?.user?.username

  useEffect(() => {
    WebApp.ready()
    WebApp.expand()
  }, [])

  useEffect(() => {
    const body = initDataRaw
      ? { initData: initDataRaw }
      : { dev: { id: userId, username } }
    axios
      .post(`${API_BASE}/api/auth/telegram`, body)
      .then((r) => setUser(r.data.user))
      .catch(() => {})
  }, [userId, username, initDataRaw])

  if (!user) return <div>Загрузка...</div>

  return (
    <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div>
        <h2>CryptoCity: Genesis</h2>
        <div>Профиль: {username || user.id}</div>
        <div>eTON: {user.eton}</div>
        <div>Дней активности: {user.activeDays}</div>
      </div>
      <WalletSection userId={user.id} />
      <Withdraw userId={user.id} activeDays={user.activeDays} />
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <button>Карта</button>
        <button>Рынок</button>
        <button>Достижения</button>
        <button>Кошелёк</button>
        <button>Настройки</button>
      </div>
    </div>
  )
}

export default function App() {
  const manifestUrl = `${location.origin}/tonconnect-manifest.json`
  return (
    <TonConnectUIProvider manifestUrl={manifestUrl} uiPreferences={{ theme: 'SYSTEM' }}>
      <AppInner />
    </TonConnectUIProvider>
  )
}
