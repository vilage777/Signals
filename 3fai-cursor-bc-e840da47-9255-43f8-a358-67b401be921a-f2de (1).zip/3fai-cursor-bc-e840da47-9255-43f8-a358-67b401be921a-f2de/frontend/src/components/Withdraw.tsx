import axios from 'axios'
import { useState } from 'react'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000'

export function Withdraw({ userId, activeDays }: { userId: string; activeDays: number }) {
  const [amount, setAmount] = useState(0.9)
  const [loading, setLoading] = useState(false)

  const onWithdraw = async () => {
    if (amount < 0.9) {
      alert('❌ Минимальная сумма вывода — 0.9 TON. Продолжай развивать город!')
      return
    }
    setLoading(true)
    try {
      await axios.post(`${API_BASE}/api/withdraw`, { id: userId, amountTon: amount })
      alert('Заявка на вывод принята! Выплата в TON инициирована.')
    } catch (e: any) {
      const code = e?.response?.data?.error
      if (code === 'need_active_5_days') alert('Нужно 5 дней активности подряд')
      else if (code === 'cooldown_7_days') alert('Можно выводить раз в 7 дней')
      else if (code === 'insufficient_eton') alert('Недостаточно eTON для вывода указанной суммы')
      else if (code === 'min_0_9_ton') alert('❌ Минимальная сумма вывода — 0.9 TON. Продолжай развивать город!')
      else alert('Ошибка вывода')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
      <input
        type="number"
        step="0.1"
        min={0.9}
        value={amount}
        onChange={(e) => setAmount(parseFloat(e.target.value))}
        style={{ flex: 1 }}
      />
      <button onClick={onWithdraw} disabled={loading || activeDays < 5}>
        Вывести прибыль
      </button>
    </div>
  )
}

